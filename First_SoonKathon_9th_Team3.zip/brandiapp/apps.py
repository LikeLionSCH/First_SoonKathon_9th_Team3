from django.apps import AppConfig


class BrandiappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'brandiapp'
